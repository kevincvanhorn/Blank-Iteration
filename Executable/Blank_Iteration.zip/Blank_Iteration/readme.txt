.jar and .exe require JRE 1.6.0 or higher

If program fails to run, provided is a low resolution video of functionality
"Executable.jar" can be unzipped to view classes